var m1 = new ReactiveVar();
m1.set(Math.floor(Math.random()*12)+1);
var m2 = new ReactiveVar();
m2.set(Math.floor(Math.random()*12)+1);
var m3 = new ReactiveVar();
m3.set(m1.get()*m2.get());

	
Template.Multiplication.helpers(
{
	check: function(){
	return Session.get("check")
	},
	correct: function(){
	return Session.get("correct")
	},
	M1:function()
	{
		return m1.get();
	},
	M2:function()
	{
	return m2.get()	;
	},
	M3:function()
	{
	return m3.get()	;
	},
}
);

Template.Multiplication.events({
//When clicking element with id Submit (i.e. the button Check!)
'click #Submit':function()
	{
// grabs the value of the element ans(i.e. the text box)
		var i=document.getElementById("ans").value
		if (i==m3.get()){
		Session.set("correct", "Correct!");
		Session.set("check", true);
		//console.log("correct!")
		}
	else
	{
		Session.set("check", true);
		Session.set("correct", "Incorrect! The answer is "+m3.get()+".");
		console.log("wrong!")
		}
	},
	'click #roll':function()
	{
		m1.set(Math.floor(Math.random()*12)+1);		
		m2.set(Math.floor(Math.random()*12)+1);
		m3.set(m1.get()*m2.get());
		console.log("HI");
	},
})
