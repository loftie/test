var question = new ReactiveVar();
question.set(Math.floor(Math.random()*3+1));


if(question.get()==1)
	{
		console.log("1")
		var b = new ReactiveVar();
		var c = new ReactiveVar();
		var d = new ReactiveVar();
		b.set(Math.floor(Math.random()*5+4));
		c.set(Math.floor(Math.random()*6+5));
		d.set("triangle");
		var a = (b*c)/2;
		
	}
	
else if(question.get()==2)
	{
		
		console.log("2")
		var b = new ReactiveVar();
		var c = new ReactiveVar();
		var d = new ReactiveVar();
		b.set(Math.floor(Math.random()*5+4));
		c.set(Math.floor(Math.random()*6+5));
		d.set("square");
		var a = (b*c);
			
	}
	
else if(question.get()==3)
	
	{
		console.log("3")
		var b = new ReactiveVar();
		var d = new ReactiveVar();
		b.set(Math.floor(Math.random()*5+4));
		d.set("circle");
		var c = Math.PI*(b.get()^2);
		var a = c.toFixed(2);
		
	};	

Template.shapes.helpers
({
	shape:function()
		{
			if(question.get()==3)
				{
					return d.get()+" with radius "+b.get();
				}
			else
				{	
					return d.get()+" with width "+b.get()+" and height "+c.get();
				}
		},
		
		
	check: function()	
		{
			return Session.get("check");
		},
	correct: function()
		{
			return Session.get("correct");
		},
})

Template.shapes.events
({
'click #sRoll':function()
{
	console.log('click');
	//Sets q to 0, otherwise if we have started with q=3, and rolled another q=3, the question would remain the same.  
	question.set();
	question.set(Math.floor(Math.random()*3+1));;
	console.log(question.get());
	
	
},	
'click #sSubmit':function()
{
	var i=document.getElementById("sAns").value
	if(i==a)
	{
		var correct = "Correct!";
		var check = true;
	}
	
	/*if (i==Session.get('a3'))
				{
					Session.set("correct", "Correct!");
					Session.set("check", true);
					Session.set("cCount", Session.get("cCount")+1);
										//console.log("correct!")
				}
			else
				{
					Session.set("check", true);
					Session.set("correct", "Incorrect! The answer is "+Session.get('a3')+".");
					console.log("wrong!")
				}	*/
	
}
	
})
