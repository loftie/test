Template.tTables.events({

'click #tsubmit':function()
	{
		Session.set('t',Number(document.getElementById("tChoice").value));
	}
	
});

var t1 = function(){return Session.get('t')*1};
var t2 = function(){return Session.get('t')*2};
var t3 = function(){return Session.get('t')*3};
var t4 = function(){return Session.get('t')*4};
var t5 = function(){return Session.get('t')*5};
var t6 = function(){return Session.get('t')*6};
var t7 = function(){return Session.get('t')*7};
var t8 = function(){return Session.get('t')*8};
var t9 = function(){return Session.get('t')*9};
var t10 = function(){return Session.get('t')*10};
var t11 = function(){return Session.get('t')*11};
var t12 = function(){return Session.get('t')*12};

Template.tTables.helpers
({
		
	tSelected: 
		[
			{tNumber: 1, tA:t1},
			{tNumber: 2, tA:t2},
			{tNumber: 3, tA:t3},
			{tNumber: 2, tA:t4},
			{tNumber: 5, tA:t5},
			{tNumber: 6, tA:t6},
			{tNumber: 7, tA:t7},
			{tNumber: 8, tA:t8},
			{tNumber: 9, tA:t9},
			{tNumber: 10, tA:t10},
			{tNumber: 11, tA:t11},
			{tNumber: 12, tA:t12},
	],
tMult : t1,

nSelect : function()
{
	return (isNaN(Session.get('t')))
},

});



