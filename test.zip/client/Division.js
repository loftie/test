var d1 = new ReactiveVar();
d1.set(Math.floor(Math.random()*11)+2);
var d2 = new ReactiveVar();
//This next line will ensure a2 is less that a1 and >=1
d2.set(Math.floor(Math.random()*(d1.get()-1)+1));

Template.Division.helpers(
{
	check: function(){
	return Session.get("check")
	},
	correct: function(){
	return Session.get("correct")
	},
	
	D3:function(){
		var d3 = d1.get() * d2.get();
		return d3;
	},
	D1:function(){
	return d1.get();
	},
	
}
);

Template.Division.events({
//When clicking element with id Submit (i.e. the button Check!)
'click #Submit':function()
	{
// grabs the value of the element ans(i.e. the text box)
		var i=document.getElementById("ans").value
		console.log(i)
		if (i==d2.get()){
		Session.set("correct", "Correct!");
		Session.set("check", true);
		//console.log("correct!")
		}
	else
	{
		Session.set("check", true);
		Session.set("correct", "Incorrect! The answer is "+d2.get()+".");
		console.log("wrong!")
		}
	},
	
'click #roll':function()
	{
		d1.set(Math.floor(Math.random()*11)+2);		
		d2.set(Math.floor(Math.random()*(d1.get()-1)+1));
		console.log("HI");
	},
})

