Template.qTypeList.helpers
(
{
	qType: [
	{ text: "Addition" },
    { text: "Subtraction" },
    { text: "Multiplication" },
	{ text: "Division" }
]
}
);

/*Template.qTypeList.events({
	'click.tab': function(){
	Session.set('selection', this.text);
	//going back to qTypeList doesn't overwrite the session when a new 'selection' is made,
	//if statement below is to make it set new variables.  
	
	if (Session.get('selection') == 'Addition')
		{
			Session.set('a3', Session.get('a1')+Session.get('a2'));
			Session.set('a4',"+");
		}
	else if (Session.get('selection') == 'Subtraction')
		{
			Session.set('a3', Session.get('a1')-Session.get('a2'));
			Session.set('a4',"-");
		}
	else if (Session.get('selection')== 'Multiplication')
		{
			Session.set('a3', Session.get('a1')*Session.get('a2'));
			Session.set('a4', "x");
		}
		
	else if (Session.get('selection')== 'Division')
		{
				Session.set('d1', Math.floor(Math.random()*11)+2);
				Session.set('d2', Math.floor(Math.random()*(Session.get('d1')-1)+1));
				Session.set('d3', Session.get('d1')*Session.get('d2'));
				Session.set('a3', Session.get('d2'));
				Session.set('a4', "/");
		}
		console.log(Session.get('selection'))
}}
)*/

