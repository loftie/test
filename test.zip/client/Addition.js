var a1 = new ReactiveVar();
a1.set(Math.floor(Math.random()*30)+2);
var a2 = new ReactiveVar();
a2.set(Math.floor(Math.random()*30)+2);
var a3 = new ReactiveVar();
a3.set(a1.get()+a2.get());

Template.Addition.helpers(
{
	check: function(){
	return Session.get("check")
	},
	correct: function(){
	return Session.get("correct")
	},
	A1:function()
	{
		return a1.get();
	},
	A2:function()
	{
	return a2.get()	;
	},
	A3:function()
	{
	return a3.get()	;
	},
	
}
);

Template.Addition.events({
//When clicking element with id Submit (i.e. the button Check!)
'click #Submit':function()
	{
// grabs the value of the element ans(i.e. the text box)
		var i=document.getElementById("ans").value
		console.log(i)
		if (i==a2.get()){
		Session.set("correct", "Correct!");
		Session.set("check", true);
		//console.log("correct!")
		}
	else
	{
		Session.set("check", true);
		Session.set("correct", "Incorrect! The answer is "+a3.get()+".");
		console.log("wrong!")
		}
	},
	
'click #roll':function()
	{
		a1.set(Math.floor(Math.random()*30)+2);
		a2.set(Math.floor(Math.random()*30)+2);
		a3.set(a1.get()+a2.get());
		console.log("HI");
	},
})

