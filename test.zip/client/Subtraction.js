var s1 = new ReactiveVar();
s1.set(Math.floor(Math.random()*30)+2);
var s2 = new ReactiveVar();
//This next line will ensure a2 is less that a1 and >=1
s2.set(Math.floor(Math.random()*(s1.get()-1)+1));
var s3 = new ReactiveVar();
s3.set(s1.get()-s2.get());
	
Template.Subtraction.helpers(
{
	check: function(){
	return Session.get("check")
	},
	correct: function(){
	return Session.get("correct")
	},
	S1:function()
	{
		return s1.get();
	},
	S2:function()
	{
	return s2.get()	;
	},
	S3:function()
	{
	return s3.get()	;
	},
	
}
);

Template.Subtraction.events({
//When clicking element with id Submit (i.e. the button Check!)
'click #Submit':function()
	{
// grabs the value of the element ans(i.e. the text box)
		var i=document.getElementById("ans").value
		if (i==s3.get()){
		Session.set("correct", "Correct!");
		Session.set("check", true);
		//console.log("correct!")
		}
	else
	{
		Session.set("check", true);
		Session.set("correct", "Incorrect! The answer is "+s3.get()+".");
		console.log("wrong!")
		}
	},
	'click #roll':function()
	{
		s1.set(Math.floor(Math.random()*30)+2);		
		s2.set(Math.floor(Math.random()*(s1.get()-1)+1));
		s3.set(s1.get()-s2.get());
		console.log("HI");
	},
})

